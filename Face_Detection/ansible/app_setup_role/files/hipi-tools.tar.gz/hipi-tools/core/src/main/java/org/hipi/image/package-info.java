/**
 * A group of classes for representing and manipulating images.
 */
package org.hipi.image;