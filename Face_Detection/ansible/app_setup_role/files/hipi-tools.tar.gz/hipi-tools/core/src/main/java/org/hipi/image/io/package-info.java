/**
 * A group of classes for reading (decoding) and writing (encoding) images in various storage
 * formats such as JPEG and PNG.
 */
package org.hipi.image.io;