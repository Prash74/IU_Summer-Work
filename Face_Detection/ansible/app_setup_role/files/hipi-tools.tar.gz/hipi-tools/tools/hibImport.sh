#!/bin/bash
TOOLS_DIR=`dirname $0`
$TOOLS_DIR/runTool.sh $TOOLS_DIR/hibImport/build/libs/hibImport.jar "$@"